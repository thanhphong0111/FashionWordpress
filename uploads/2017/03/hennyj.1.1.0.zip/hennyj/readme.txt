Hennyj WordPress Theme, Copyright 2015 Malvouz
Hennyj is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Hennyj WordPress Theme is derived from Underscores WordPress Theme, Copyright 2015

Hennyj WordPress Theme bundles the following third-party resources:

Underscores Based WordPress Theme
Source: http://underscores.me/

Genericons icon font, Copyright 2015 Automattic
Genericons are licensed under the terms of the GNU GPL, Version 2 (or later)
Source: http://www.genericons.com

FlexSlider, 
FlexSlider is no longer licensed under the MIT license. FlexSlider now uses the license, GPLv2 and later.
Source: http://www.woothemes.com/flexslider/

Bootstrap,
Bootstrap is released under the MIT license and is copyright 2015 Twitter. Boiled down to smaller chunks, it can be described with the following conditions.
It requires you to:

    Keep the license and copyright notice included in Bootstrap's CSS and JavaScript files when you use them in your works

It permits you to:

    Freely download and use Bootstrap, in whole or in part, for personal, private, company internal, or commercial purposes
    Use Bootstrap in packages or distributions that you create
    Modify the source code
    Grant a sublicense to modify and distribute Bootstrap to third parties not included in the license

It forbids you to:

    Hold the authors and license owners liable for damages as Bootstrap is provided without warranty
    Hold the creators or copyright holders of Bootstrap liable
    Redistribute any piece of Bootstrap without proper attribution
    Use any marks owned by Twitter in any way that might state or imply that Twitter endorses your distribution
    Use any marks owned by Twitter in any way that might state or imply that you created the Twitter software in question

It does not require you to:

    Include the source of Bootstrap itself, or of any modifications you may have made to it, in any redistribution you may assemble that includes it
    Submit changes that you make to Bootstrap back to the Bootstrap project (though such feedback is encouraged)

Source: http://getbootstrap.com/css/


jQuery-Tiles-Gallery is based on GPL License, https://wordpress.org/plugins/final-tiles-grid-gallery-lite

Subtle Patterns by Subtle Patterns is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License.
http://subtlepatterns.com/symphony/

All Image for the Demos Purpose and Screenshot are from https://pixabay.com

Direcnt link to Pixabay:
1. Child Football : https://pixabay.com/en/child-footballer-kick-backswing-613199/
2. Child Blue : https://pixabay.com/en/girl-child-pretty-person-human-903401/
3. Child Play: https://pixabay.com/en/child-husband-play-kite-wind-510604/
4. Child : https://pixabay.com/en/aroni-arsa-children-little-model-738306/ 

Screenshoot for image:
1. Pixabay - https://pixabay.com/en/aron-arsa-model-little-kissing-920236/

2. Pixabay - https://pixabay.com/en/aroni-arsa-children-little-model-738302/